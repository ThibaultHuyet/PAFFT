var searchData=
[
  ['r',['R',['../classsp_1_1_f_f_t_w.html#a41f4792359384f83d6896ca26ba442c5',1,'sp::FFTW::R()'],['../classsp_1_1_f_i_r__filt.html#a02bf1d681193e803e3c12c5d6d33b0c0',1,'sp::FIR_filt::R()'],['../group__kalman.html#ga997c1165b080a5581128fef2e986d94f',1,'sp::KF::R()']]],
  ['rows',['rows',['../classsp_1_1_p_n_m.html#ad2ce56b6363043f197ac8f897d1b8bba',1,'sp::PNM']]]
];
