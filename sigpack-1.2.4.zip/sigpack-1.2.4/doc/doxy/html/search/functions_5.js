var searchData=
[
  ['fd_5ffilter',['fd_filter',['../group__filter.html#ga12f93d9568b9b5df785b77504ad37291',1,'sp']]],
  ['fft',['fft',['../classsp_1_1_f_f_t_w.html#ac64d3666f8c9602e1a9e74afd676f405',1,'sp::FFTW::fft(arma::vec &amp;x, arma::cx_vec &amp;Pxx)'],['../classsp_1_1_f_f_t_w.html#a1009e05281f55f63772ecbd2d67b4f53',1,'sp::FFTW::fft(arma::vec &amp;x)']]],
  ['fft2',['fft2',['../classsp_1_1_f_f_t_w.html#a7b23da6f279f50926012395f0f18009f',1,'sp::FFTW::fft2(arma::mat &amp;x, arma::cx_mat &amp;Pxx)'],['../classsp_1_1_f_f_t_w.html#a33344b15ea8585832e273161a72db381',1,'sp::FFTW::fft2(arma::mat &amp;x)']]],
  ['fft_5fcx',['fft_cx',['../classsp_1_1_f_f_t_w.html#af3d3a1c61486e257a56389083169ef62',1,'sp::FFTW::fft_cx(arma::cx_vec &amp;x, arma::cx_vec &amp;Pxx)'],['../classsp_1_1_f_f_t_w.html#a8821465ad3f60607b4add3ad58167493',1,'sp::FFTW::fft_cx(arma::cx_vec &amp;x)']]],
  ['fftshift',['fftshift',['../group__data.html#gac82c53579045c08aaaabab389ac16a6b',1,'sp::fftshift(const arma::Col&lt; T &gt; &amp;Pxx)'],['../group__data.html#ga379ab4d8b10b6ec705bc1b536ea6c88e',1,'sp::fftshift(const arma::Mat&lt; T &gt; &amp;Pxx)']]],
  ['fftw',['FFTW',['../classsp_1_1_f_f_t_w.html#a1e5779e505daa7a7bbd0b1be058dc005',1,'sp::FFTW::FFTW(unsigned int _N, int _alg=FFTW_ESTIMATE)'],['../classsp_1_1_f_f_t_w.html#a339b447102c5e55dbd395ea1de8eba57',1,'sp::FFTW::FFTW(unsigned int _R, unsigned int _C, int _alg)']]],
  ['figure',['figure',['../classsp_1_1gplot.html#a503113f2ddc855d453517ecdf6c004db',1,'sp::gplot']]],
  ['filter',['filter',['../classsp_1_1_f_i_r__filt.html#aee810c6c8e0109990d89cc11b0ed1085',1,'sp::FIR_filt::filter(const arma::Mat&lt; T1 &gt; &amp;in)'],['../classsp_1_1_f_i_r__filt.html#aebc4bcfc85ec225d720060d1c14e1071',1,'sp::FIR_filt::filter(const arma::Col&lt; T1 &gt; &amp;in)'],['../classsp_1_1_i_i_r__filt.html#a97e513891ad46ce92e14563c0d1cc27e',1,'sp::IIR_filt::filter()']]],
  ['fir1',['fir1',['../group__filter.html#ga7589b226840d7ead6db4921954316952',1,'sp']]],
  ['fir1_5fbp',['fir1_bp',['../group__filter.html#gac372a9f5df673d52d5120800573aa350',1,'sp']]],
  ['fir1_5fbs',['fir1_bs',['../group__filter.html#ga14e4ea76494bd64b7bfa7b80cda0d087',1,'sp']]],
  ['fir1_5fhp',['fir1_hp',['../group__filter.html#gab4bbc830b9ce254970976a5e38502650',1,'sp']]],
  ['fir_5ffilt',['FIR_filt',['../classsp_1_1_f_i_r__filt.html#abc87a2054ab2d8aba596aa06d1fc9ca4',1,'sp::FIR_filt']]],
  ['flattopwin',['flattopwin',['../group__window.html#gabef4639aa5814635d8973e1027dd4bd4',1,'sp']]],
  ['freq',['freq',['../group__filter.html#gad44af04160b953f812b291e46c99ac0b',1,'sp']]],
  ['freqz',['freqz',['../group__filter.html#gaecd49125d26a649152a7db62140e8940',1,'sp']]]
];
