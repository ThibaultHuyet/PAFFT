var searchData=
[
  ['jacobian_5fanalytical',['jacobian_analytical',['../group__kalman.html#ga9c870b7b11a02dfc9e8c4784d058184a',1,'sp::EKF::jacobian_analytical(arma::mat &amp;_F, fcn_m _f_m, const arma::mat &amp;_x)'],['../group__kalman.html#ga2ac526f13e559c74d6bcec7eda0b7685',1,'sp::EKF::jacobian_analytical(arma::mat &amp;_F, fcn_m _f_m)']]],
  ['jacobian_5fdiff',['jacobian_diff',['../group__kalman.html#ga756b17e2d9e361830c76e76adb6e9e54',1,'sp::EKF::jacobian_diff(arma::mat &amp;_F, fcn_v _f, const arma::mat &amp;_x)'],['../group__kalman.html#ga936ca96644dc342eb085601c08352291',1,'sp::EKF::jacobian_diff(arma::mat &amp;_F, fcn_v _f)']]]
];
