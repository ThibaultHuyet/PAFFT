var searchData=
[
  ['ifft',['ifft',['../classsp_1_1_f_f_t_w.html#a8cdbeee097e35bc525fd6194725ee3ff',1,'sp::FFTW::ifft(arma::cx_vec &amp;Pxx, arma::vec &amp;x)'],['../classsp_1_1_f_f_t_w.html#a49e615fc778231d27fb64a19fce28f45',1,'sp::FFTW::ifft(arma::cx_vec &amp;Pxx)']]],
  ['ifft2',['ifft2',['../classsp_1_1_f_f_t_w.html#ad6f456f92246352c424838a7821e2c18',1,'sp::FFTW::ifft2(arma::cx_mat &amp;Pxx, arma::mat &amp;x)'],['../classsp_1_1_f_f_t_w.html#a2f9139375ac5b9afc6b1b008da78bfc3',1,'sp::FFTW::ifft2(arma::cx_mat &amp;Pxx)']]],
  ['ifft_5fcx',['ifft_cx',['../classsp_1_1_f_f_t_w.html#a045303d4027ee2cebf7acc94f9a6a77b',1,'sp::FFTW::ifft_cx(arma::cx_vec &amp;Pxx, arma::cx_vec &amp;x)'],['../classsp_1_1_f_f_t_w.html#aaafa35957d8433550f293b407f5a62dc',1,'sp::FFTW::ifft_cx(arma::cx_vec &amp;Pxx)']]],
  ['ifftshift',['ifftshift',['../group__data.html#ga1bc06372dee0d8438a1abc2302e61b27',1,'sp::ifftshift(const arma::Col&lt; T &gt; &amp;Pxx)'],['../group__data.html#ga802ba5cb262005922933d787f75fe8a0',1,'sp::ifftshift(const arma::Mat&lt; T &gt; &amp;Pxx)']]],
  ['iir_5ffilt',['IIR_filt',['../classsp_1_1_i_i_r__filt.html#a5049d36219530673432b21d95c903d2c',1,'sp::IIR_filt']]],
  ['image',['image',['../classsp_1_1gplot.html#aa7a28ff8724c1dad44501dfc2d8b4a9c',1,'sp::gplot::image(const arma::mat &amp;x)'],['../classsp_1_1gplot.html#af450fbdebd027c24d5364432dbcb9ffa',1,'sp::gplot::image(const arma::cube &amp;x)']]],
  ['import_5fwisdom_5ffile',['import_wisdom_file',['../classsp_1_1_f_f_t_w.html#ab5517d934c0088da508009e9a278f0eb',1,'sp::FFTW']]],
  ['import_5fwisdom_5fstring',['import_wisdom_string',['../classsp_1_1_f_f_t_w.html#acbca0584ced6dccecece01396b58dd82',1,'sp::FFTW']]]
];
