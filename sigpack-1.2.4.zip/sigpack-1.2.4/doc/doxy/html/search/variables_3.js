var searchData=
[
  ['d',['D',['../classsp_1_1_delay.html#a34c23ec1a55a24cf13aa05e110223caa',1,'sp::Delay']]],
  ['do_5fadapt',['do_adapt',['../classsp_1_1_f_i_r__filt.html#a8faa5a35b968da40ac02bc1191e2cd5d',1,'sp::FIR_filt']]],
  ['dx',['dx',['../group__kalman.html#gae42c4251d6fab7126646ffb4f7aeca58',1,'sp::EKF']]]
];
