var searchData=
[
  ['export_5falg',['export_alg',['../classsp_1_1_f_f_t_w.html#ac64d2ba92cf0f91e98aaa396119fb4cb',1,'sp::FFTW']]]
];
