var searchData=
[
  ['a',['a',['../classsp_1_1_i_i_r__filt.html#a033d49e2188e41cf4962ab564f7c8f5c',1,'sp::IIR_filt::a()'],['../group__kalman.html#ga0dc244269951eee6f66c98313d50e05a',1,'sp::KF::A()']]],
  ['a_5fbuf',['a_buf',['../classsp_1_1_i_i_r__filt.html#a724b945ba5e575e3ffa3adb5b82cdb48',1,'sp::IIR_filt']]],
  ['a_5fcur_5fp',['a_cur_p',['../classsp_1_1_i_i_r__filt.html#ae00c806f731d892829191a122a1a6811',1,'sp::IIR_filt']]],
  ['aa_5ffilt',['aa_filt',['../classsp_1_1resampling.html#a5a8f3d9fb99a0e81b37013394782bfb1',1,'sp::resampling']]],
  ['adapt_5fdisble',['adapt_disble',['../classsp_1_1_f_i_r__filt.html#a7ce575cb131763b23dbce217e672a15a',1,'sp::FIR_filt']]],
  ['adapt_5fenable',['adapt_enable',['../classsp_1_1_f_i_r__filt.html#a136001c1c79bb7208d5b4c75e2f5b2ab',1,'sp::FIR_filt']]],
  ['alg',['alg',['../classsp_1_1_f_f_t_w.html#a0dbd3fa3dfb09c078f1463d2211314fe',1,'sp::FFTW']]],
  ['alpha',['alpha',['../group__kalman.html#ga26a03f7ce12a820bcac7f9c9b6b309c9',1,'sp::UKF']]],
  ['angle',['angle',['../group__math.html#ga6ca474d672e6dbba09f0c85de3a0f528',1,'sp::angle(const std::complex&lt; T &gt; &amp;x)'],['../group__math.html#ga4647fd218d0b63d8fa05acb568a26684',1,'sp::angle(const arma::cx_vec &amp;x)'],['../group__math.html#ga79d307e7b42c72672bfffb18f92408ba',1,'sp::angle(const arma::cx_mat &amp;x)']]]
];
