var searchData=
[
  ['resampling',['Resampling',['../group__resampling.html',1,'']]]
];
