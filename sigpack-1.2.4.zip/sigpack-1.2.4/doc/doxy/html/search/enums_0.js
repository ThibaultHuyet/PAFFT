var searchData=
[
  ['imtype',['imtype',['../classsp_1_1_p_n_m.html#a5f970fa81d4758dbcfeebc32c20db45e',1,'sp::PNM']]]
];
