var searchData=
[
  ['spectrum',['Spectrum',['../group__spectrum.html',1,'']]]
];
