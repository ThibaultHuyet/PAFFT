var searchData=
[
  ['term',['term',['../classsp_1_1gplot.html#a8db663da49031e7708cb5647ad37598f',1,'sp::gplot']]],
  ['type',['type',['../classsp_1_1_p_n_m.html#a740cea4f800c8d3cc90f3d5d4bc17dc6',1,'sp::PNM']]]
];
