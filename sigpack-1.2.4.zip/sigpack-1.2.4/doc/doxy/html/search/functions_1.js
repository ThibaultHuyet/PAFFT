var searchData=
[
  ['besseli0',['besseli0',['../group__math.html#ga54e62d13bad85015db897ff0827cd237',1,'sp']]],
  ['blackman',['blackman',['../group__window.html#ga19ff5e9a5b7626c98cfcc45223891cc4',1,'sp']]],
  ['blackmanharris',['blackmanharris',['../group__window.html#gaa96c59fdb7d40201ae6b291e5927965c',1,'sp']]]
];
