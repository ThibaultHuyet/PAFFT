var searchData=
[
  ['window',['window',['../classsp_1_1gplot.html#af8a89b7d89ade87f9803ebe99c0110db',1,'sp::gplot::window(const int fig, const char *name, const int x, const int y, const int width, const int height)'],['../classsp_1_1gplot.html#a3a29f27a99a7ca98bca4fda7657afc55',1,'sp::gplot::window(const char *name, const int x, const int y, const int width, const int height)'],['../group__window.html',1,'(Global Namespace)']]],
  ['window_2eh',['window.h',['../window_8h.html',1,'']]],
  ['wp',['Wp',['../group__kalman.html#gaefa098aac5536dd25f30343faf0f8f5c',1,'sp::UKF']]],
  ['write',['write',['../classsp_1_1_p_n_m.html#a521b2c087d2a137b7d78562f34df2505',1,'sp::PNM::write(std::string fname, const imtype _type, const arma::cube &amp;img, const string info=&quot;&quot;)'],['../classsp_1_1_p_n_m.html#a6ca6203d904a34c9bfc357dac07a5811',1,'sp::PNM::write(std::string fname, const imtype _type, arma::mat &amp;img, const string info=&quot;&quot;)']]],
  ['write_5fheader',['write_header',['../classsp_1_1_p_n_m.html#acd0edcc3104565a1bf1a8a4431d425ad',1,'sp::PNM']]],
  ['wrn_5fhandler',['wrn_handler',['../group__misc.html#ga84ecc1749809aceb1501750803e3b191',1,'base.h']]],
  ['wx',['Wx',['../group__kalman.html#ga11b9112bd717e7cd3b7e0e29b8539e16',1,'sp::UKF']]]
];
