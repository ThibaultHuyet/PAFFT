var searchData=
[
  ['adapt_5fdisble',['adapt_disble',['../classsp_1_1_f_i_r__filt.html#a7ce575cb131763b23dbce217e672a15a',1,'sp::FIR_filt']]],
  ['adapt_5fenable',['adapt_enable',['../classsp_1_1_f_i_r__filt.html#a136001c1c79bb7208d5b4c75e2f5b2ab',1,'sp::FIR_filt']]],
  ['angle',['angle',['../group__math.html#ga6ca474d672e6dbba09f0c85de3a0f528',1,'sp::angle(const std::complex&lt; T &gt; &amp;x)'],['../group__math.html#ga4647fd218d0b63d8fa05acb568a26684',1,'sp::angle(const arma::cx_vec &amp;x)'],['../group__math.html#ga79d307e7b42c72672bfffb18f92408ba',1,'sp::angle(const arma::cx_mat &amp;x)']]]
];
