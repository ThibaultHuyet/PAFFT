var searchData=
[
  ['newt_5fadapt',['newt_adapt',['../classsp_1_1_f_i_r__filt.html#a5e0d3ebcd445863adfa4f98322c9eccf',1,'sp::FIR_filt']]],
  ['nlms_5fadapt',['nlms_adapt',['../classsp_1_1_f_i_r__filt.html#a513cc813aae2611bb748dc3470da0812',1,'sp::FIR_filt']]]
];
