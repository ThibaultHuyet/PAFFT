var searchData=
[
  ['q',['Q',['../classsp_1_1_f_i_r__filt.html#ac8418befccca49067373f507e63aac6b',1,'sp::FIR_filt::Q()'],['../group__kalman.html#ga32bec326068a62473cd4893906e060b0',1,'sp::KF::Q()'],['../classsp_1_1resampling.html#a579370c98a9742732fab0509258d8937',1,'sp::resampling::Q()']]]
];
