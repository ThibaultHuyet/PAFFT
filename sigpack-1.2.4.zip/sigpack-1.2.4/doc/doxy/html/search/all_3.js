var searchData=
[
  ['d',['D',['../classsp_1_1_delay.html#a34c23ec1a55a24cf13aa05e110223caa',1,'sp::Delay']]],
  ['data',['Data',['../group__data.html',1,'']]],
  ['delay',['Delay',['../classsp_1_1_delay.html',1,'sp']]],
  ['delay',['Delay',['../classsp_1_1_delay.html#aa03a5548a51d67d1dc913d7f2a6602df',1,'sp::Delay::Delay()'],['../classsp_1_1_delay.html#ae1647362ef0edfba204c73e7f700698e',1,'sp::Delay::Delay(const arma::uword _D)'],['../classsp_1_1_delay.html#a298afce51b2135f9e5cd22b09d220a44',1,'sp::Delay::delay(const arma::Col&lt; T1 &gt; &amp;in)']]],
  ['do_5fadapt',['do_adapt',['../classsp_1_1_f_i_r__filt.html#a8faa5a35b968da40ac02bc1191e2cd5d',1,'sp::FIR_filt']]],
  ['downfir',['downfir',['../classsp_1_1resampling.html#a1bc48e60609fcf3e2d1266ca772a493c',1,'sp::resampling']]],
  ['downsample',['downsample',['../group__resampling.html#gaddf025d233d862c9f8536f60cb573306',1,'sp']]],
  ['dx',['dx',['../group__kalman.html#gae42c4251d6fab7126646ffb4f7aeca58',1,'sp::EKF']]]
];
