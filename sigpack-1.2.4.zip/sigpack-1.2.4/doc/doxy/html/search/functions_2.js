var searchData=
[
  ['clear',['clear',['../classsp_1_1_f_i_r__filt.html#a18dcb8ee939612a822837f90991c23e0',1,'sp::FIR_filt::clear()'],['../classsp_1_1_i_i_r__filt.html#afee32a34b810f27154d13a6898bf67a7',1,'sp::IIR_filt::clear()'],['../classsp_1_1_p_n_m.html#a981192179bdf56cd61a3f438e0c3a8fb',1,'sp::PNM::clear()'],['../group__kalman.html#ga49743587fa197b9cb77e8b29a247b801',1,'sp::KF::clear()'],['../classsp_1_1_delay.html#a5336f9359b4bcc76b73feea2cbf08211',1,'sp::Delay::clear()']]],
  ['close_5fwindow',['close_window',['../classsp_1_1gplot.html#a35db351e86e3b4bbe1f55e380e38a834',1,'sp::gplot']]],
  ['cos_5fwin',['cos_win',['../group__window.html#ga8ac728241659eeb4ab11ffc86bdbe30c',1,'sp']]]
];
