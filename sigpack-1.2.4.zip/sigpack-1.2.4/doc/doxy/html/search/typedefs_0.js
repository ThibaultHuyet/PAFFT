var searchData=
[
  ['fcn_5fm',['fcn_m',['../namespacesp.html#a30344a5ad826b1bf5497db790b47c8f2',1,'sp']]],
  ['fcn_5ft',['fcn_t',['../namespacesp.html#a113cf9d0049bda1be2fef9b9f23d51b7',1,'sp']]],
  ['fcn_5fv',['fcn_v',['../namespacesp.html#ade5a21f4ae4bcc581f641ce94b11485b',1,'sp']]]
];
