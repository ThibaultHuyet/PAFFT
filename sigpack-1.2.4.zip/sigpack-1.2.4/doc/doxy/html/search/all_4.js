var searchData=
[
  ['ekf',['EKF',['../classsp_1_1_e_k_f.html',1,'sp']]],
  ['ekf',['EKF',['../group__kalman.html#gad21ce233e90a94b822c9163fce5d5f39',1,'sp::EKF']]],
  ['err_5fhandler',['err_handler',['../group__misc.html#gacb7674b570d02259d7fcdd8f71375b77',1,'base.h']]],
  ['eval_5ffcn',['eval_fcn',['../namespacesp.html#affd2e0601b0fb2bfbe92b2fab39edc1d',1,'sp::eval_fcn(const fcn_v f, const arma::mat &amp;x, const arma::mat &amp;u, const arma::mat &amp;w)'],['../namespacesp.html#a7bbb24a9b2eafabd242ec43767530943',1,'sp::eval_fcn(const fcn_v f, const arma::mat &amp;x, const arma::mat &amp;u)'],['../namespacesp.html#a78fdf31229868f5b39a4758edd8fcb2f',1,'sp::eval_fcn(const fcn_v f, const arma::mat &amp;x)']]],
  ['export_5falg',['export_alg',['../classsp_1_1_f_f_t_w.html#ac64d2ba92cf0f91e98aaa396119fb4cb',1,'sp::FFTW']]],
  ['export_5fwisdom_5ffft',['export_wisdom_fft',['../classsp_1_1_f_f_t_w.html#aa1017fe5375c48ce3ed2ab4994f2ee44',1,'sp::FFTW']]],
  ['export_5fwisdom_5ffft_5fcx',['export_wisdom_fft_cx',['../classsp_1_1_f_f_t_w.html#a5071397908132690df29eb0de9eed178',1,'sp::FFTW']]],
  ['export_5fwisdom_5fifft',['export_wisdom_ifft',['../classsp_1_1_f_f_t_w.html#a90d06a02fc583d8534c67ec59da69aac',1,'sp::FFTW']]],
  ['export_5fwisdom_5fifft_5fcx',['export_wisdom_ifft_cx',['../classsp_1_1_f_f_t_w.html#a411e068607e2d6952d3cdf7a23b2e014',1,'sp::FFTW']]]
];
