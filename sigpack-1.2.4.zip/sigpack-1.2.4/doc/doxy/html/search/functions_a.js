var searchData=
[
  ['kaiser',['kaiser',['../group__window.html#gae2147feff9ac4af4923e4c95a5ea2aa1',1,'sp']]],
  ['kalman_5fadapt',['kalman_adapt',['../classsp_1_1_f_i_r__filt.html#a183c3b910574a04eda0b5ebe239bf24c',1,'sp::FIR_filt']]],
  ['kf',['KF',['../group__kalman.html#ga39c470ccc1e5059bf56d7a060daa616c',1,'sp::KF']]]
];
