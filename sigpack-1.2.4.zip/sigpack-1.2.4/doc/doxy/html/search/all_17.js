var searchData=
[
  ['x',['x',['../group__kalman.html#ga32ae4cd8a33e2feaf0e557253ac04240',1,'sp::KF::x()'],['../group__kalman.html#gaee8a9962cac3549eaaec9d4781a33a4d',1,'sp::UKF::X()']]],
  ['x_5ftpz',['X_tpz',['../classsp_1_1_f_i_r__filt.html#a9ddb3c593a06573d1f87363994fb3d1d',1,'sp::FIR_filt']]],
  ['xlabel',['xlabel',['../classsp_1_1gplot.html#a4c22b57ea40033580cb4b688f78a1f5f',1,'sp::gplot']]],
  ['xlim',['xlim',['../classsp_1_1gplot.html#a7cfec49f060678c9bd674e7da2921be4',1,'sp::gplot']]]
];
