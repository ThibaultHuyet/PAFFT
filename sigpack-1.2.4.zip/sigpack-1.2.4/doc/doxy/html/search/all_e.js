var searchData=
[
  ['ofs',['ofs',['../classsp_1_1_p_n_m.html#a4805957c3c87474d9d5e11e2aab97bb3',1,'sp::PNM']]],
  ['operator_28_29',['operator()',['../classsp_1_1_f_i_r__filt.html#acf51123a460745bb64f44eec0e245683',1,'sp::FIR_filt::operator()()'],['../classsp_1_1_i_i_r__filt.html#ada68a6cf91f30a4bf1326040e6819114',1,'sp::IIR_filt::operator()()'],['../classsp_1_1_delay.html#a984e6e25a2d65dd8b458009e4dd18401',1,'sp::Delay::operator()()']]]
];
